
#import <UIKit/UIKit.h>

@interface RCCLightBox : NSObject
+(void)showWithParams:(NSDictionary*)params;
+(void)dismiss;
@end
