package com.reactnativenavigation.controllers;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;

public class ActivityCallbacks {
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

    }

    public void onActivityStarted(Activity activity) {

    }

    public void onActivityResumed(Activity activity) {

    }

    public void onActivityPaused(Activity activity) {

    }

    public void onActivityStopped(Activity activity) {

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

    }

    public void onActivityDestroyed(Activity activity) {

    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

    }

    public void onNewIntent(Intent intent) {

    }

    public void onConfigurationChanged(Configuration newConfig) {

    }

    public void onKeyUp(int keyCode, KeyEvent event) {

    }

}
