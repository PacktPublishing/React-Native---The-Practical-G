export const INITIALIZED = 'example.app.INITIALIZED';
export const ROOT_CHANGED = 'example.app.ROOT_CHANGED';
