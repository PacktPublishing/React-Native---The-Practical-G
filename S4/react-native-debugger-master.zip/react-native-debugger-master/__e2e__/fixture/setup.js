/* eslint no-underscore-dangle: 0 */

self.window = global;

// Remove native fetch as react-native use whatwg-fetch polyfill
self.fetch = undefined;

const requiredModules = {
  NativeModules: {},
  Platform: {},
  setupDevtools: undefined,
  AsyncStorage: {},
  MessageQueue: {
    spy: () => {},
    prototype: { __spy: null },
  },
};
// Simulate React Native's window.require polyfill
window.require = moduleName => {
  // From https://github.com/facebook/react-native/blob/5403946f098cc72c3d33ea5cee263fb3dd03891d/packager/src/Resolver/polyfills/require.js#L97
  console.warn(
    `Requiring module '${moduleName}' by name is only supported for ` +
      'debugging purposes and will BREAK IN PRODUCTION!'
  );
  return requiredModules[moduleName];
};
window.__DEV__ = true;
