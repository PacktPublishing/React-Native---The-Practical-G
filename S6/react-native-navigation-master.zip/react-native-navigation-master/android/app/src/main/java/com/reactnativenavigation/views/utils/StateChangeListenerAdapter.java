package com.reactnativenavigation.views.utils;

import android.view.View;

class StateChangeListenerAdapter implements View.OnAttachStateChangeListener {
    @Override
    public void onViewAttachedToWindow(View view) {

    }

    @Override
    public void onViewDetachedFromWindow(View view) {

    }
}
