All notable changes are described on the [Releases](https://github.com/reduxjs/react-redux/releases) page.
