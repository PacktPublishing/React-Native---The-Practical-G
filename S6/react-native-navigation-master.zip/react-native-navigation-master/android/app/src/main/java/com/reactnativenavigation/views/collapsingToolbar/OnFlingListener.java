package com.reactnativenavigation.views.collapsingToolbar;

interface OnFlingListener {
    void onFling(CollapseAmount amount);
}
