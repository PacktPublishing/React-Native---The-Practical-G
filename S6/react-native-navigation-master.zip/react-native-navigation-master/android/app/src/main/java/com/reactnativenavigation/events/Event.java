package com.reactnativenavigation.events;

public interface Event {
    String getType();
}
