export default {
  SCSocket: {},
};
