//
//  RNNSwizzles.h
//  ReactNativeNavigation
//
//  Created by Leo Natan (Wix) on 1/17/18.
//  Copyright © 2018 artal. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RNNSwizzles : NSObject

+ (void)applySwizzles;

@end
