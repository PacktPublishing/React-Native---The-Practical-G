package com.reactnativenavigation.views.collapsingToolbar;

import android.widget.ScrollView;

public interface OnScrollViewAddedListener {
    void onScrollViewAdded(ScrollView scrollView);
}
