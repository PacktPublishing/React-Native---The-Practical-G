require('electron-debug')(); // eslint-disable-line
