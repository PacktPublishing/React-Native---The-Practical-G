package com.reactnativenavigation.params.parsers;

import com.reactnativenavigation.params.InterpolationParams;

public class SharedElementTransitionParams {
    public InterpolationParams interpolation;
    public int duration;
    public boolean animateClipBounds;
}
