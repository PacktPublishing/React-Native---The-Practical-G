#import <UIKit/UIKit.h>
#import <React/RCTConvert.h>

@interface RCTConvert (UIBarButtonSystemItem)

+ (UIBarButtonSystemItem)UIBarButtonSystemItem:(id)json;

@end
